kubectl exec -it $(kubectl get pod -l app=task-app -n devops -o jsonpath="{.items[0].metadata.name}") -n devops -- bash -c 'cat > /var/www/html/config/db.php << EOF
<?php
\$db_host = "mysql";
\$db_user = "root";
\$db_pass = "root123";
\$db_name = "devopsdb";

\$conn = new mysqli(\$db_host, \$db_user, \$db_pass, \$db_name);

if (\$conn->connect_error) {
    die("Connection failed: " . \$conn->connect_error);
}

if (\$_SERVER["REQUEST_METHOD"] === "POST") {
    \$name        = \$conn->real_escape_string(\$_POST["name"]);
    \$designation = \$conn->real_escape_string(\$_POST["designation"]);
    \$task        = \$conn->real_escape_string(\$_POST["task"]);

    \$sql = "INSERT INTO tasks (name, designation, task) VALUES (\047\$name\047, \047\$designation\047, \047\$task\047)";

    if (\$conn->query(\$sql) === TRUE) {
        echo "<h2>Success! Your submission was saved.</h2>";
    } else {
        echo "Error: " . \$conn->error;
    }
}

\$conn->close();
?>
EOF'
